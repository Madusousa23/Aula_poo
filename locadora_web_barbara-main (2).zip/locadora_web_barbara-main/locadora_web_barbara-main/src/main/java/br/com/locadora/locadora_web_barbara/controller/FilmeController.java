package br.com.locadora.locadora_web_barbara.controller;

import br.com.locadora.locadora_web_barbara.model.Filme;
import br.com.locadora.locadora_web_barbara.service.LocadoraService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/filmes") //definir o barra filme como inicio de todas as rodas dessa classe
public class FilmeController {
    private final LocadoraService service; //Guardar referencia do service usado pelo controller

    public  FilmeController(LocadoraService service) {
        this.service = service; //Guarda o objeto recebido no atributo
    }
    @GetMapping("/novo")
    public String abrirFormulario(Model model){ //objetos usado para enviar dados do java -> html
        model.addAttribute("filme", new Filme()); //Envia o objeto vazio, chamado filme para o formulario
        return "filme/formulario";
    }
    @PostMapping("/salvar") //recebe a rota post para salvar
    public String salvarFilmes(@ModelAttribute Filme filme,Model model){ //pede ao string para preencher um objeto "Filme" para os dados enviados
        try{
            //inicia bloco que pode gerar erro de regra
            service.cadastrarFilme(filme);//entrega o objeto ao service
            return "redirect:/filmes?sucesso=true"; //manda o navegador abrir a listagem dos filmes e acrescenta um parametro de sucesso
        }catch (IllegalArgumentException erro){ //captura uma regra invalida lançada pelo service
            model.addAttribute("mensagemErro", erro.getMessage());//Obter a mensagem de erro
            return "filme/formulario";
        }
    }
    @GetMapping
    public String listarFilmes(Model model){
        model.addAttribute("filmes", service.listarFilmes());//envia a lista de filmes para a página
        return "filme/lista";
    }


}
