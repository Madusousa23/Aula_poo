package br.com.locadora.locadora_web_barbara.service;

import br.com.locadora.locadora_web_barbara.model.Filme;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

    /*
    Contem regras de negocio da locadora
     */

@Service //faz o spring do springboot
public class LocadoraService{
    private final List<Filme>filmes; //declara a lista que guarda os filmes na memória
    private int proximoCodigoFilme; //guarda o código do filme na memória



    public LocadoraService(){
        filmes = new ArrayList<>();
        proximoCodigoFilme = 1;
    }
    public void  cadastrarFilme(Filme filme){
        filme.setCodigo(proximoCodigoFilme);
        proximoCodigoFilme++;
        filmes.add(filme);
    }
    public List<Filme>listarFilmes(){
        return  new ArrayList<>(filmes);//cria uma cópia da lista para proteger a lista interna
    }
    public Filme buscarFilmePorCodigo(int codigo){
        for (Filme filme: filmes){
            if (filme.getCodigo() == codigo){
                return filme;
            }

        }
        return null;
    }

}

