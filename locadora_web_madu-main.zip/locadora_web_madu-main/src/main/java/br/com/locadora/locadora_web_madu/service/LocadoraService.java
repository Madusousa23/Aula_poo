package br.com.locadora.locadora_web_madu.service;

import br.com.locadora.locadora_web_madu.model.Filme;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

//Contém as regras de negócio da Locadora
@Service  //indica que a classe é um serviço do Spring (que passa a gerenciar a mesma)
public class LocadoraService {
    private final List<Filme> filmes; //declara a lista de filmes
    private int proximoCodigoFilme; //guarda o próximo código automaticamente

    public LocadoraService() {
        filmes = new ArrayList<>(); //cria lista vazia
        proximoCodigoFilme = 1;
    }

    //synchronized: o service é um singleton compartilhado entre requisições simultâneas
    public synchronized void cadastrarFilme(Filme filme) {
        if (filme == null) {
            throw new IllegalArgumentException("Filme inválido.");
        }
        if (filme.getNome() == null || filme.getNome().isBlank()) {
            throw new IllegalArgumentException("O nome do filme é obrigatório.");
        }
        if (filme.getGenero() == null || filme.getGenero().isBlank()) {
            throw new IllegalArgumentException("O gênero do filme é obrigatório.");
        }
        filme.setNome(filme.getNome().trim());
        filme.setGenero(filme.getGenero().trim());
        filme.setCodigo(proximoCodigoFilme);
        proximoCodigoFilme++;
        filmes.add(filme);
    }

    public synchronized List<Filme> listarFilmes() {
        //cria uma cópia da lista para proteger a lista interna
        return new ArrayList<>(filmes);
    }

    public synchronized Filme buscarFilmePorCodigo(int codigo) {
        for (Filme filme : filmes) {
            if (filme.getCodigo() == codigo) {
                return filme;
            }
        }
        return null;
    }

}
