package br.com.locadora.locadora_web_madu;

import br.com.locadora.locadora_web_madu.model.Filme;
import br.com.locadora.locadora_web_madu.service.LocadoraService;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LocadoraServiceTest {

    @Test
    void cadastraFilmeComCodigoAutomaticoEDisponivel() {
        LocadoraService service = new LocadoraService();
        Filme filme = new Filme();
        filme.setNome("  Matrix ");
        filme.setGenero("Ficção");

        service.cadastrarFilme(filme);

        assertEquals(1, filme.getCodigo());
        assertEquals("Matrix", filme.getNome());
        assertFalse(filme.isAlugado());
        assertEquals(1, service.listarFilmes().size());
    }

    @Test
    void codigoIncrementaACadaCadastro() {
        LocadoraService service = new LocadoraService();
        service.cadastrarFilme(new Filme("A", 0, "Drama"));
        service.cadastrarFilme(new Filme("B", 0, "Ação"));

        assertEquals(2, service.buscarFilmePorCodigo(2).getCodigo());
        assertNull(service.buscarFilmePorCodigo(99));
    }

    @Test
    void rejeitaNomeOuGeneroEmBranco() {
        LocadoraService service = new LocadoraService();
        assertThrows(IllegalArgumentException.class,
                () -> service.cadastrarFilme(new Filme("  ", 0, "Drama")));
        assertThrows(IllegalArgumentException.class,
                () -> service.cadastrarFilme(new Filme("Matrix", 0, "")));
        assertTrue(service.listarFilmes().isEmpty());
    }

    @Test
    void alugarDuasVezesLancaErroEDevolverLibera() {
        Filme filme = new Filme("Matrix", 1, "Ficção");
        filme.alugar();
        assertTrue(filme.isAlugado());
        assertThrows(IllegalArgumentException.class, filme::alugar);
        filme.devolver();
        assertFalse(filme.isAlugado());
    }
}
