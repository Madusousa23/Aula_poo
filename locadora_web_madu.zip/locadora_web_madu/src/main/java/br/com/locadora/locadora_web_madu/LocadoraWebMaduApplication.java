package br.com.locadora.locadora_web_madu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LocadoraWebMaduApplication {

    public static void main(String[] args) {
        SpringApplication.run(LocadoraWebMaduApplication.class, args);
    }

}
