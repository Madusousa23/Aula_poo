package br.com.locadora.locadora_web_madu.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

//coloca a classe do objeto controler
//controla a classe pacote

//importa a anotação que identifica o controller

@Controller //informa ao string que a classe recebe acesso do navegador
public class HomeController { //declara o controller da página inicial
    @GetMapping("/") // liga o endereço principal ao método abaixo
    public String abrirPaginaInicial(){
        return "index";
    }
}
