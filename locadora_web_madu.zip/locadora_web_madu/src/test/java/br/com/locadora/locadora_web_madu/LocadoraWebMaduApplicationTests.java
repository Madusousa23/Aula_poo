package br.com.locadora.locadora_web_madu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocadoraWebMaduApplicationTests {

    @Test
    void contextLoads() {
    }

}
