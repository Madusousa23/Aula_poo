package exerciciosbase;
public class Cliente {

   // Scanner teste = new Scanner(System.in);
   // System.out.println("Digite o seu nome : ");
  //  String nome = teste.nextLine();

  //  System.out.println("Digite o seu telefone :  s");
   // String telefone = teste.nextLine();

    String nome;
    String telefone;

    /*
    Cria o atributo nome e telefone, como texto.
     */
}
