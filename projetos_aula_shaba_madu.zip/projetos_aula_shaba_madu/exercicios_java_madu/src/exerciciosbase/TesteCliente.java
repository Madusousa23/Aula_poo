package exerciciosbase;
import java.util.Scanner;

public class TesteCliente {

    //psvma
    public static void main(String[] args ) {
        Scanner sc = new Scanner(System.in);


        Cliente cliente = new Cliente();

        //Declarar uma referencia e cria uma nova objeto Cliente com o new
        System.out.println("Digite o nome do Cliente: ");

        cliente.nome = sc.nextLine();

        System.out.println("Digite o Telefone do cliente :  ");
        cliente.telefone = sc.nextLine();

        System.out.println("------------Cliente Cadastrado--------------");
        System.out.println("Nome: " + cliente.nome);
        System.out.println("Telefone " + cliente.telefone);




        sc.close();

    }
}
