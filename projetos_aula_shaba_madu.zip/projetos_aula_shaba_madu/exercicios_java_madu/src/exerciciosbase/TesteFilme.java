package exerciciosbase;

import java.util.Scanner;

public class TesteFilme {
    public static void main(String[] args) {
        Scanner madu = new Scanner(System.in);

        System.out.println("Digite o Nome do filme : ");
        String nome = madu.nextLine();

        System.out.println("Digite o gênero do Filme");
        String genero = madu.nextLine();

        System.out.println("O filme está alugado ? (S/N)");
        char resposta = madu.next().charAt(0);
        //charat pega uma posição

        boolean alugado = resposta == 'S' || resposta == 's';
        System.out.println();
        System.out.println("---------DADOS DO FILME------------");
        System.out.println("Nome: " + nome);
        System.out.println("Gênero: " + genero);

        if(alugado){
            System.out.println("Status: Alugado") ;
        }else{
            System.out.println("Status: Disponível");
        }

        madu.close();
    }

}
